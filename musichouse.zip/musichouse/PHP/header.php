<?php
session_start();
include "connect.php";
$menu = '
    <li class="nav-item">
      <h3><a class="nav-link px-2 text-dark" href="index.php"><strong>О нас</strong></a></h3>
    </li>
    <li class="nav-item">
    <h3><a class="nav-link px-2 text-dark" href="catalog.php"><strong>Каталог</strong></a></h3>
    </li>
    <li class="nav-item">
    <h3><a class="nav-link px-2 text-dark" href="location.php"><strong>Где нас найти</strong></a></h3>
    </li>
     %s
    ';

$m = '';
if(isset($_SESSION["role"])) {
    $m = ' <li class="nav-item"><a class="nav-link active" href="cart.php">Корзина</a></li>';
    $m .= ($_SESSION["role"] == "admin") ? '<li class="nav-item"><a class="nav-link active" href="admin.php">Заказы</a></li>' : '';
    $m .= '<form class="d-flex ms-auto"><button class="btn btn-dark me-2" type="submit" formaction="index.php">Выйти</button></form>';
} else {
    $b = '
        <form class="d-flex ms-auto">
        <button class="btn btn-dark me-2" type="submit" formaction="login.php">Войти</button>
        <button class="btn btn-dark" type="submit" formaction="register.php">Регистрация</button>
        </form>
    ';
}
$menu = sprintf($menu, $m);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Интернет-магазин</title>
    <link rel="stylesheet" href="resourse/bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="logo/logo.ico" type="image/x-icon">
    <script src="scripts/filter.js"></script>
    <script>
        let role = "<?= (isset($_SESSION["role"])) ? $_SESSION["role"] : "guest" ?>";
    </script>
</head>
<body>

<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container mt">
            <a class="navbar-brand" href="index.php">
                <img class="d-inline-block align-top" src="logo/logo1.jpg" alt="Логотип компании" />
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav justify-content-around d-flex " >
                    <?= $menu ?>
                </ul>
                <form class="d-flex ms-auto">
                 <?=$b?>
                </form>
            </div>
        </div>
    </nav>
</header>

<div class="message"><?= (isset($_GET["message"])) ? $_GET["message"] : ""; ?></div>

<script src="resourse/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
