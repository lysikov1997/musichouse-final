<footer class=" sticky-bottom py-3 my-4 mb-auto">
	<div class="container-fluid">
			<ul class="nav justify-content-center border-bottom pb-3 mb-3">
				<?= $menu ?>
			</ul>
			<p class="text-center text-light">© 2023 Music House</p>
		</div>
</nav>
	</footer>
	
</body>
</html>