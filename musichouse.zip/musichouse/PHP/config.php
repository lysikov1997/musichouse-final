<?php 
$host = "localhost"; // Имя хоста
$username = "root"; // Ваше имя пользователя базы данных
$password = ""; // Ваш пароль базы данных
$database = "db_demo_2023"; // Имя вашей базы данных

$connection = new mysqli($host, $username, $password, $database);
if ($connection->connect_error) {
    die("Ошибка подключения: " . $connection->connect_error);
}