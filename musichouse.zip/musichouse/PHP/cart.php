<?php
    session_start();
    // include "controllers/check.php";
	include "config.php";
	include "header.php";

	
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['product_id'];
    $action = $_POST['action'];
	
	$role = (isset($_SESSION["role"])) ? $_SESSION["role"] : "guest";
	$id = (isset($_GET["id"])) ? $_GET["id"] : 0;

	$sql = "SELECT `count` FROM `products` WHERE `product_id` = " . $id;
	if(!$result = $connect->query($sql))
		return die("Ошибка получения данных: " . $connect->error);

	$maxCount = 0;
	if($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$count = $row['count'];
			if($count > $maxCount) {
				$maxCount = $count;
			}
		}
	}

	if($maxCount == 0)
		return header("Location:index.php?message=Достигнут лимит");
    } 
    $sql = sprintf("SELECT `order_id`, `product_id`, `orders`.`count`, `name`, `price`, `path` FROM `orders` INNER JOIN `products` USING(`product_id`) WHERE `user_id`='%s'", $_SESSION["user_id"]);
	$result = $connect->query($sql);

	$products = "";
	while($row = $result->fetch_assoc())
		$products .= sprintf('
			<div class="col">
				<img src="%s" alt="">
				<div class="row">
					<h3><a href="product.php?id=%s">%s</a></h3>
					<p>%s руб.</p>
				</div>
				<div class="row">
					<p><a href="controllers/delete_cart.php?id=%s">Убрать</a></p>
					<p id="c1">%s</p>
					<p><a href="controllers/add_cart.php?id=%s">Добавить</a></p>
				</div>
			</div>
		', $row["path"], $row["product_id"], $row["name"], $row["price"], $row["product_id"], $row["count"], $row["product_id"]);

	if($products == "")
		$products = '<h3 class="text-center">Товары в корзине отсутствуют</h3>';

	$sql = sprintf("SELECT * FROM `orders` WHERE `user_id`='%s' AND `number` IS NOT NULL AND `product_id`=0 ORDER BY `created_at` DESC", $_SESSION["user_id"]);
	$result = $connect->query($sql);

	$orders = "";
	while($row = $result->fetch_assoc()) {
		$del = ($row["status"] == "Новый") ? '<p class="text-right"><a onclick="return confirm(\'Удалить этот заказ?\')" href="controllers/delete_order.php?id='.$row["order_id"].'" class="text-small">Удалить заказ</a></p>' : '';
		$orders .= sprintf('
			      <td>
                    <h2>Заказ  %s</h2>
                    <p>Статус: <b>%s</b></p>
                    <p>Количество товаров: <b>%s</b></p>
                  </td>
		', $row["number"], $del, $row["status"], $row["count"]);
	}

	if($orders == "")
		$orders = '<h3 class="text-center">Список заказов пуст</h3>';


?>

<main>
	<div class="message"></div>
	<div class="container-sm">
		<h1>Ваша корзина</h1>
		<div class="row">
			<?= $products ?>
		</div>
		<br>
		<form action="controllers/checkout.php" class="w-100" method="POST">
			<input class="form-control" type="password" placeholder="Ваш пароль" name="password" required>
			<br>
			<button class="btn btn-success">Сформировать заказ</button>
		</form>
	</div>
	<br>
	<div class="container-sm">
		<h1>Ваши заказы</h1>
		<div class="row">
			<div class="col-12">
				<table class="table table-bordered">
					<tbody>
						<tr>
						<?= $orders ?>
						<tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>

	
</main>

<?php include "footer.php" ?>
