<?php
session_start();
// Подключение к базе данных
include('config.php');

// Обработка отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $surname = $_POST['surname'];
    $patronymic = $_POST['patronymic'];
    $login = $_POST['login'];
    $email = $_POST['email'];
    $password = $_POST["password"];
    $password_repeat = $_POST['password_repeat'];
    $rules = isset($_POST['rules']) ? $_POST['rules'] : '';

    // Проверка, существует ли пользователь с таким же именем
    $query = "SELECT * FROM `users` WHERE `login` = '$login'";
    $result = $connection->query($query);
    if ($result->num_rows > 0) {
        echo "Пользователь с таким именем уже существует.";
        exit;
    } 
    
    // Проверка совпадения паролей
    if ($password !== $password_repeat) {
        echo "Пароли не совпадают.";
        exit;
      }
    

    // Проверка валидности email-адреса
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Некорректный email-адрес.";
        exit;
    }

    // Хеширование пароля
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Проверка обязательных полей
    if (empty($name) || empty($surname) || empty($login) || empty($email) || empty($password) || empty($password_repeat)) {
        echo "Пожалуйста, заполните все обязательные поля.";
        exit;
    }
    
    // Добавление пользователя в базу данных
    $sql = "INSERT INTO `users` (`name`, `surname`, `patronymic`, `login`, `email`, `password`, `role`) VALUES ('$name', '$surname', '$patronymic', '$login', '$email', '$hashed_password', 'guest')";
    if ($connection->query($sql) === TRUE) {
        // Регистрация прошла успешно
        header("Location: cart.php");
        exit;
    } else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header("Location: register.php");
        echo "Ошибка регистрации: " . $connection->error;
        exit;
    }
}

$connection->close();
?>
