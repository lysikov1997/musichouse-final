<?php
session_start();
// Подключение к базе данных
require_once('config.php');

// Проверка, была ли отправлена форма
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получение введенных пользователем данных
    $login = $_POST['login'];
    $password = $_POST['password'];

    
    // Подготовка запроса для поиска пользователя по логину
    $stmt = $connection->prepare('SELECT * FROM users WHERE login = ?');
    $stmt->bind_param('s', $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Проверка пароля
        if (password_verify($password, $user["password"])) {
            // Авторизация успешна
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // Перенаправление на домашнюю страницу после успешной авторизации
            header("Location: cart.php");
            exit();
        } else {
            // Неправильный пароль
            $_SESSION['login_error'] = 'Неправильный пароль.';
        }
    } else {
        // Пользователь не найден
        $_SESSION['login_error'] = 'Пользователь не найден.';
    }

    $stmt->close();
    $connection->close();

    // Перенаправление на страницу входа после ошибки авторизации
    header('Location: login.php');
    exit();
} else {
    // Если форма не была отправлена, перенаправление на страницу входа
    header('Location: login.php');
    exit();
}
exit();
?>
