<?php
session_start();
// Подключение к базе данных
include('config.php');
?>
  

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Регистрация</title>
  <link rel="stylesheet" href="resourse/bootstrap-5.0.2-dist/css/bootstrap.min.css">
</head>

<body>
  <div class="container">
    <h1 class="mt-4">Регистрация нового пользователя</h1>
    <!-- проверка переменной $error -->
    <?php if (isset($error)) : ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>

    <form id="registerForm" method="POST" action="process_register.php">
      <div class="mb-3">
        <label for="name" class="form-label">Имя:</label>
        <input type="text" class="form-control" id="name" name="name" required>
      </div>
      <div class="mb-3">
        <label for="surname" class="form-label">Фамилия:</label>
        <input type="text" class="form-control" id="surname" name="surname" required>
      </div>
      <div class="mb-3">
        <label for="patronymic" class="form-label">Отчество:</label>
        <input type="text" class="form-control" id="patronymic" name="patronymic">
      </div>
      <div class="mb-3">
        <label for="login" class="form-label">Логин:</label>
        <input type="text" class="form-control" id="login" name="login" required>
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email:</label>
        <input type="email" class="form-control" id="email" name="email" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Пароль:</label>
        <input type="password" class="form-control" id="password" name="password" minlength="6" required>
      </div>
      <div class="mb-3">
        <label for="passwordRepeat" class="form-label">Повторите пароль:</label>
        <input type="password" class="form-control" id="passwordRepeat" name="password_repeat" required>
      </div>
      <div class="form-check mb-3">
        <input type="checkbox" class="form-check-input" id="rules" name="rules" required>
        <label class="form-check-label" for="rules">Согласен с правилами регистрации</label>
      </div>
      <button type="submit" class="btn btn-dark">Зарегистрироваться</button>
      <button type="button" class="btn btn-dark btn-sm" onclick="goBack()">Назад</button>
      <p class="msg">
      <?php 
if (isset($_SESSION['message'])) {
    echo '<p class="msg">' . $_SESSION['message'] . '</p>';
    unset($_SESSION['message']);
}
?>

      </p>


    </form>
  </div>

  <script>
function goBack() {
  window.history.back();
}
</script>
</body>

</html>
