-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 07 2023 г., 11:13
-- Версия сервера: 10.8.4-MariaDB
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `db_demo_2023`
--
CREATE DATABASE IF NOT EXISTS `db_demo_2023` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_demo_2023`;

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`category_id`, `category`) VALUES
(1, 'Гитара'),
(2, 'Пианино'),
(3, 'Скрипка');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `number` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`order_id`, `product_id`, `user_id`, `number`, `count`, `status`, `reason`, `created_at`, `updated_at`) VALUES
(17, 0, 2, 1387869029, 1, 'Отменённый', 'dwa', '2022-02-17 10:15:08', '2023-06-05 20:41:39'),
(38, 0, 1, 1386600174, 1, 'Новый', NULL, '2023-06-07 00:39:07', '2023-06-07 00:39:07'),
(40, 0, 1, 1072530572, 1, 'Новый', NULL, '2023-06-07 00:39:13', '2023-06-07 00:39:13');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `country` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int(4) NOT NULL,
  `model` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  `path` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `country`, `year`, `model`, `category`, `count`, `path`, `created_at`) VALUES
(1, 'Аккордовая гитара', 4000, 'Япония', 2023, 'Обычная', 'Гитара', 1, 'images/guitar1.jpeg', '2023-06-02 19:32:45'),
(3, 'Необычная гитара', 4000, 'Швеция', 2023, 'Необычная', 'Гитара', 10, 'images/guitar2.jpeg', '2023-06-05 19:32:45'),
(4, 'Яркое пианино', 5000, 'Италия', 2023, 'Обычное', 'Пианино', 1, 'images/piano1.jpeg', '2023-06-05 19:32:45'),
(5, 'Скрипка', 15000, 'Голландия', 2022, 'Необычная', 'Скрипка', 103, 'images/violin1.jpeg', '2023-06-05 19:32:45'),
(6, 'Супер пианино', 40000, 'Россия', 2022, 'Обычное', 'Пианино', 2, 'images/piano2.jpeg', '2023-06-05 19:32:45'),
(7, 'Рубцовая гитара', 41000, 'Россия', 2021, 'Необычная', 'Гитара', 647, 'images/guitar3.jpeg', '2023-06-05 19:32:45'),
(8, 'Скрипка ', 11000, 'Колечия', 2021, 'Обычная', 'Скрипка', 55, 'images/violin2.jpeg', '2023-06-08 21:00:00'),
(9, 'Гитара обычная', 53000, 'Швеция', 2020, 'Необычная', 'Гитара', 4, 'images/guitar4.jpeg', '2023-06-05 19:32:45'),
(10, 'Басовая гитара', 56000, 'Швеция', 2020, 'Обычная', 'Гитара', 32, 'images/guitar5.jpeg', '2023-06-05 19:32:45'),
(11, 'Десятая скрипка', 9000, 'Италия', 2019, 'Необычная', 'Скрипка', 1, 'images/violin3.jpeg', '2023-06-05 19:32:45'),
(12, 'Кашерное пианино', 62000, 'СССР', 2019, 'Обычное', 'Пианино', 87, 'images/piano3.jpeg', '2023-06-05 19:32:45'),
(13, 'Отличная скрипка', 28000, 'Германия', 2019, 'Необычная', 'Скрипка', 23, 'images/violin4.jpeg', '2023-06-05 19:32:45'),
(14, 'Пригодное пианино', 32000, 'Италия', 2018, 'Обычное', 'Пианино', 32, 'images/piano2.jpeg', '2023-06-05 19:32:45'),
(15, 'Вариабельная гитара', 47000, 'Швеция', 2018, 'Необычная', 'Гитара', 95, 'images/guitar6.jpeg', '2023-06-05 19:32:45'),
(16, 'Драмм-гитара', 34000, 'Япония', 2018, 'Обычная', 'Гитара', 117, 'images/guitar2.jpeg', '2023-06-05 19:32:45'),
(17, 'Неистовая гитара', 31000, 'Россия', 2017, 'Необычная', 'Гитара', 7, 'images/guitar4.jpeg', '2023-04-28 18:32:45'),
(18, 'Надежная скрипка', 45000, 'СССР', 2017, 'Обычная', 'Скрипка', 2, 'images/violin2.jpeg', '2023-06-05 19:32:45'),
(19, 'Красивое пианино', 12000, 'Голландия', 2017, 'Необычное', 'Пианино', 3, 'images/piano3.jpeg', '2023-06-05 19:32:45'),
(20, 'Интересное пианино', 46000, 'Германия', 2016, 'Обычное', 'Пианино', 3, 'images/piano1.jpeg', '2023-06-05 19:32:45');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patronymic` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `name`, `surname`, `patronymic`, `login`, `email`, `password`, `role`) VALUES
(1, 'Aдмин', 'Админов', 'Админович', 'admin', '1@1', 'admin', 'admin'),
(2, 'Михаил', 'Лысиков', ' ', '1', '1@1', '111111', 'guest'),
(4, 'йцууцй', 'уцйуй', 'уцйуйц', 'qwe', 'lysikov1997@list.ru', '$2y$10$6rm8m8SJ8nXEPfVSEbzYyuPrOZpIJZ9/bSINteq9K.N4nJNrbaaqW', 'guest'),
(5, 'йцууцй', 'уцйуй', 'уцйуйц', 'qwe', 'lysikov1997@list.ru', 'qwe', 'guest'),
(6, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe@qewq.ru', '$2y$10$Mjh2QjJD8gBWTuJ7KHPkSOEUpHMwN8VWBUn5jYCsZTX4GM8Eu/9Le', 'guest'),
(7, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe@qewq.ru', '$2y$10$XbtUfvZyvXhy4EzI1Xx6I.gUl5ep..aj0XCtSY8D7A6Ar41UIUFhe', 'guest'),
(8, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe@qewq.ru', '$2y$10$UGFVycJRkXs0soZLxabFsOYb4vmhAZmpS8aLWLHig3v7taOLK03uy', 'guest'),
(9, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe@qewq.ru', '$2y$10$6kM//YabMEIb3S5NBN/ye.bHcU3RppoGhDN0Pf88mGE0AD/adQD7u', 'guest'),
(10, 'qwe', 'qwe', 'qwe', 'qwe', 'qwe@qewq.ru', '$2y$10$jU0IJKNo1VDf/8PSk1oXLOlyARV4E2juaVyBr7VjawrTD9etA8jui', 'guest'),
(11, 'Михаил ', 'Лысиков', '', 'lysikov', 'lysikov1997@list.ru', '$2y$10$MOXdPeKuQBJuB9NvefexD.2umjrsOToU2c8XQvx2xHuFNQFyMeBLG', 'guest'),
(12, 'Михаил ', 'Лысиков', '', 'lysikov', 'lysikov1997@list.ru', '$2y$10$29c33gpSrcV3ylkXgulW1e1BB2XmFUsw6tU/9eOtZHpep3u1f2lBy', 'guest'),
(13, '123456', '123456', '', '123456', '123456dwad@dwad.ru', '123456', 'guest'),
(14, '123456', '123456', '', '123456', '123456dwad@dwa.ru', '', 'guest'),
(15, '123456', '123456', '', '1234567', '123456dwad@dwa.ru', '$2y$10$b2bU3q9.oGPLtQoOe//GsulOemPIeHcJWAJewEagsvhZJcB38OcgS', 'guest'),
(16, '123456', '123456', '', '12345678', '123456dwad@dwa.ru', '$2y$10$jccqJ5x/ebEj2Pd3gFcMtOl629jX1JLUDRKzCE3VYite09NZf0RYC', 'guest'),
(17, 'lysikov1997@list.ru', 'lysikov1997@list.ru', '', 'lysikov1997@list.ru', 'lysikov1997@list.ru', '$2y$10$evOKifqLhhBphgbxecqyYOGD88QSS6EFY8EmOw6KD.068r5Zia1Pm', 'guest'),
(18, 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ru1', 'lysikov1997@list.ru', '$2y$10$OLfxm2PSYPowq.10nuzs6ePN3csUdxtfP/7LzHPfCLVkXWkin2Sjq', 'guest'),
(19, 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ru12', 'lysikov1997@list.ru', '$2y$10$boz./DLxUFxNRFWPLaYSSeIWLsLwZRvywOd5DlNZbp7MprGs/j1Te', 'guest'),
(24, 'Михаил', 'Михаил', '', 'dwada', 'dawdawd@dwam', 'dwaddawd', 'guest'),
(25, 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ru', 'lysikov1997@list.ruвцф', 'lysikov1997@list.ru', '$2y$10$HV.o2ftfOlL3tUHpm8nrrOxhUjXjcUJtWUzo/PZTZggX0Q6zvnpIe', 'guest'),
(26, '321321', '31231', '', '31313', '31313@wq.ru', '$2y$10$ypwA.p..aH8BDFMjl2LVMu49IGfyS5SdNeqaxqPlb6DV44o6CgyEi', 'guest');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
