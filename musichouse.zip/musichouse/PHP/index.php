<?php
session_start();
include "config.php";
include "header.php";

// Выборка последних 5 товаров из базы данных
$sql = "SELECT * FROM `products` WHERE `count` > 0 ORDER BY `created_at` DESC LIMIT 5";
$result = $connect->query($sql);

$data = ''; // Переменная для хранения кода слайдов
$active = true; // Флаг для определения активного слайда

// Создание слайдов на основе данных из базы
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imagePath = htmlspecialchars($row["path"]);
        $productId = htmlspecialchars($row["product_id"]);
        $productName = htmlspecialchars($row["name"]);
        
        // Определение класса для слайда
        $slideClass = 'carousel-item';
        if ($active) {
            $slideClass .= ' active';
            $active = false;
        }
        
        // Форматирование слайда с использованием sprintf
        $slide = sprintf(
            '<div class="%s">
                <img src="%s" alt="">
                <div class="carousel-caption">
                    <h3 class="text-center"><a class="text-white text-decoration-none" href="product.php?id=%s">%s</a></h3>
                </div>
            </div>',
            $slideClass,
            $imagePath,
            $productId,
            $productName
        );
        
        $data .= $slide; // Добавление слайда к общей переменной $data
    }
}

if (empty($data)) {
    $data = '<h3 class="text-center">Товары отсутствуют</h3>';
}

$connect->close();
?>
<script>
document.addEventListener('keydown', function(event) {
  var carouselElement = document.querySelector('.carousel');
  var carousel = bootstrap.Carousel.getInstance(carouselElement);
  
  if (event.key === 'ArrowLeft') {
    carousel.prev();
  } else if (event.key === 'ArrowRight') {
    carousel.next();
  }
});</script>
<main>
    <div class="message">
        <div class="col-12 text-center">
            <h1 class="text-danger"></h1>
        </div>
    </div>
    <section class="container mt-5">
        <div class="row">
            <div class="col-12 text-center">
                <h1>Погрузитесь в мир музыки с лучшими акустическими инструментами</h1>
            </div>
        </div>
    </section>

    <div class="content">
        <section class="container mt-5">
            <h2 class="text-center mb-5">Новинки компании</h2>
            <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?= $data ?>
                </div>
                <button class="carousel-control-prev " type="button" data-bs-target="#carouselExample"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Предыдущий</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Следующий</span>
                </button>
            </div>
        </section>
    </div>
</main>
<script>
  // Инициализация карусели и управление активным слайдом с помощью JavaScript
  var carousel = new bootstrap.Carousel(document.getElementById('carouselExample'), {
    interval: 3500, // Интервал смены слайдов (опционально)
    wrap: true // Позволяет карусели продолжать циклом после последнего слайда (опционально)
  });
</script>
<?php include "footer.php" ?>
<script src="resourse/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
