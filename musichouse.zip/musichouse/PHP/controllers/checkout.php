<?php
	include "check.php";
	include "../config.php";

	$sql = sprintf("SELECT * FROM `users` WHERE `user_id`='%s'", $_SESSION["user_id"]);
	if($config->query($sql)->fetch_assoc()["password"] != $_POST["password"])
		return header("Location:../cart.php?message=Ошибка пароля");

	$sql = sprintf("SELECT SUM(`count`) FROM `orders` WHERE `user_id`='%s' AND `number` IS NULL", $_SESSION["user_id"]);
	$count = $config->query($sql)->fetch_array()[0];

	$config->query(sprintf("INSERT INTO `orders`(`product_id`, `user_id`, `number`, `count`, `status`) VALUES('0', '%s', '%s', '%s', 'Новый')", $_SESSION["user_id"], rand(1000000000, 2000000000), $count));

	$config->query(sprintf("DELETE FROM `orders` WHERE `user_id`='%s' AND `number` IS NULL", $_SESSION["user_id"]));

	return header("Location:../cart.php?message=Заказ оформлен");