<?php
	include "check_admin.php";
	include "../config.php";

	$config->query("DELETE FROM `categories` WHERE `category`=".$_POST["category"]);

	return header("Location:../admin?message=Категория удалена");