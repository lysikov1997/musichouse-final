<?php
	session_start();
	include "header.php";
?>

	<main>
		<div class="container mt-4">
    <div class="row">
      <div class="col-md-6">
        <h2>Наши контакты</h2>
        <p>Адрес: г.Москва, Ленинградское шоссе, 13 А</p>
        <p>Телефон: +7 777 456-78-90</p>
        <p>Почта: example123@example.com</p>
      </div>
      <div class="col-md-6">
        <img src="images/map.jpg" class="img-fluid" alt="Карта">
      </div>
    </div>
  </div>
	</main>

<?php include "footer.php" ?>