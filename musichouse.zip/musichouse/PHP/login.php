<?php
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получение введенных пользователем данных
    $login = $_POST['login'];
    $password = $_POST['password'];



    $stmt = $connect->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->bind_param("s", $_POST['login']);
    $stmt->execute();
    $result = $stmt->get_result();

    
    if (!$result) {
        die("Ошибка получения данных: " . $connect->error);
    }
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user["password"] == $_POST["password"]) {
            $_SESSION["user_id"] = $user["user_id"];
            $_SESSION["role"] = $user["role"];
    
            header("Location: ../cart.php");
            exit;
        }
    }
    
    header("Location: ../index.php?message=Ошибка логина или пароля");
    exit;

}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Вход</title>
  <!-- Подключение Bootstrap CSS -->
  <link rel="stylesheet" href="resourse/bootstrap-5.0.2-dist/css/bootstrap.min.css">
</head>

<body><!-- Pills navs -->

<?php if (isset($error)) : ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Авторизация</h2>

                <?php if (isset($_SESSION['login_error'])) : ?>
                    <p class="alert alert-danger" role="alert">
                        <?php echo $_SESSION['login_error']; ?>
                    </p>
                    <?php unset($_SESSION['login_error']); ?>
               <?php endif; ?>

                <form action="process_login.php" method="POST">
                    <div class="mb-3">
                        <label for="login" class="form-label">Логин</label>
                        <input type="text" class="form-control" id="login" name="login" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="text-center gap-2">
                        <button type="submit" class="btn btn-dark btn-lg">Войти</button>
                        <button type="button" class="btn btn-dark btn-sm" onclick="goBack()">Назад</button>
                    </div>
                    
                </form>
            </div>
        </div>
    </div>


    <script>
function goBack() {
  window.history.back();
}
</script>
</body>

</html>
<!-- Pills content -->